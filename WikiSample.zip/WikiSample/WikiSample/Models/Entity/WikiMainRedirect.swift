//
//	WikiMainRedirect.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation


class WikiMainRedirect : NSObject, NSCoding{

	var from : String!
	var index : Int!
	var to : String!


	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		from = dictionary["from"] as? String
		index = dictionary["index"] as? Int
		to = dictionary["to"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if from != nil{
			dictionary["from"] = from
		}
		if index != nil{
			dictionary["index"] = index
		}
		if to != nil{
			dictionary["to"] = to
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         from = aDecoder.decodeObject(forKey: "from") as? String
         index = aDecoder.decodeObject(forKey: "index") as? Int
         to = aDecoder.decodeObject(forKey: "to") as? String

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if from != nil{
			aCoder.encode(from, forKey: "from")
		}
		if index != nil{
			aCoder.encode(index, forKey: "index")
		}
		if to != nil{
			aCoder.encode(to, forKey: "to")
		}

	}

}