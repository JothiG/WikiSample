//
//	WikiMainPage.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation


class WikiMainPage : NSObject, NSCoding{

	var index : Int!
	var ns : Int!
	var pageid : Int!
	var terms : WikiMainTerm!
	var thumbnail : WikiMainThumbnail!
	var title : String!


	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		index = dictionary["index"] as? Int
		ns = dictionary["ns"] as? Int
		pageid = dictionary["pageid"] as? Int
		if let termsData = dictionary["terms"] as? [String:Any]{
			terms = WikiMainTerm(fromDictionary: termsData)
		}
		if let thumbnailData = dictionary["thumbnail"] as? [String:Any]{
			thumbnail = WikiMainThumbnail(fromDictionary: thumbnailData)
		}
		title = dictionary["title"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if index != nil{
			dictionary["index"] = index
		}
		if ns != nil{
			dictionary["ns"] = ns
		}
		if pageid != nil{
			dictionary["pageid"] = pageid
		}
		if terms != nil{
			dictionary["terms"] = terms.toDictionary()
		}
		if thumbnail != nil{
			dictionary["thumbnail"] = thumbnail.toDictionary()
		}
		if title != nil{
			dictionary["title"] = title
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         index = aDecoder.decodeObject(forKey: "index") as? Int
         ns = aDecoder.decodeObject(forKey: "ns") as? Int
         pageid = aDecoder.decodeObject(forKey: "pageid") as? Int
         terms = aDecoder.decodeObject(forKey: "terms") as? WikiMainTerm
         thumbnail = aDecoder.decodeObject(forKey: "thumbnail") as? WikiMainThumbnail
         title = aDecoder.decodeObject(forKey: "title") as? String

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if index != nil{
			aCoder.encode(index, forKey: "index")
		}
		if ns != nil{
			aCoder.encode(ns, forKey: "ns")
		}
		if pageid != nil{
			aCoder.encode(pageid, forKey: "pageid")
		}
		if terms != nil{
			aCoder.encode(terms, forKey: "terms")
		}
		if thumbnail != nil{
			aCoder.encode(thumbnail, forKey: "thumbnail")
		}
		if title != nil{
			aCoder.encode(title, forKey: "title")
		}

	}

}