//
//	WikiMainSearch.swift
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation


class WikiMainSearch : NSObject, NSCoding{

	var batchcomplete : Bool!
	var continueField : WikiMainContinue!
	var query : WikiMainQuery!


	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		batchcomplete = dictionary["batchcomplete"] as? Bool
		if let continueFieldData = dictionary["continue"] as? [String:Any]{
			continueField = WikiMainContinue(fromDictionary: continueFieldData)
		}
		if let queryData = dictionary["query"] as? [String:Any]{
			query = WikiMainQuery(fromDictionary: queryData)
		}
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if batchcomplete != nil{
			dictionary["batchcomplete"] = batchcomplete
		}
		if continueField != nil{
			dictionary["continue"] = continueField.toDictionary()
		}
		if query != nil{
			dictionary["query"] = query.toDictionary()
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         batchcomplete = aDecoder.decodeObject(forKey: "batchcomplete") as? Bool
         continueField = aDecoder.decodeObject(forKey: "continue") as? WikiMainContinue
         query = aDecoder.decodeObject(forKey: "query") as? WikiMainQuery

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if batchcomplete != nil{
			aCoder.encode(batchcomplete, forKey: "batchcomplete")
		}
		if continueField != nil{
			aCoder.encode(continueField, forKey: "continue")
		}
		if query != nil{
			aCoder.encode(query, forKey: "query")
		}

	}

}