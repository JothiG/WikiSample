//
//  Loader.swift
//  carbookPlus
//
//  Created by widas concepts on 11/02/16.
//  Copyright © 2016 Widas. All rights reserved.
//

import UIKit
import MBProgressHUD
class Loader: NSObject {
    class func ShowLoaderInView(_ view:UIView,using hud:MBProgressHUD?, message:String = "Please Wait",callback : @escaping (MBProgressHUD?) ->())  {
        DispatchQueue.main.async {
            let spinnerActivity : MBProgressHUD?
            if hud != nil{
                hud?.hide(animated: false)
            }
            spinnerActivity = MBProgressHUD.showAdded(to: view, animated: true)
            spinnerActivity?.bezelView.backgroundColor = UIColor .black
            spinnerActivity?.contentColor = UIColor.white
            spinnerActivity?.label.text = message
            spinnerActivity?.label.numberOfLines = 2
            callback(spinnerActivity)
        }
    }
    
    class func HideLoader(_ view:UIView){
            DispatchQueue.main.async {
                MBProgressHUD.hide(for: view, animated: true)
            }
    }
    
}
